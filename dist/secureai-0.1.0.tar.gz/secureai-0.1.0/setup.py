from setuptools import setup

setup(
    name="secureai",
    version="0.1.0",
    description="Secured you GenAI models using securedai",
    long_description="This is very long description for securedai",
    author="Varinder CTO",
    packages=["securedai"],
    install_requires=["python-decouple==3.8"]
)